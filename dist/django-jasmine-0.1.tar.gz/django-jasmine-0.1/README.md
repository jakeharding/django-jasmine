django-jasmine
============

django-jasmine integrates the [Jasmine Javascript testing framework][1] with [Django][2].  Jasmine is a behavior-driven development framework for testing your JavaScript code. It does not depend on any other JavaScript frameworks. It does not require a DOM. And it has a clean, obvious syntax so that you can easily write tests.

  [1]: http://pivotal.github.com/jasmine/
  [2]: http://www.djangoproject.com/

installation
============

 1. Add 'django_jasmine' to your settings.INSTALLED_APPS.
 2. Add settings.JASMINE_TEST_DIRECTORY, containing the path to your javascript jasmine test files.*
 3. Add all Javascript files (including jQuery, and any other libraries) to files.json
 4. Add a urlconf to include('django_jasmine.urls').
 5. Visit the URL you've included in your urlconf to display Jasmine test results.

*See the example directory for more information.*

license
=======

Copyright (c) 2010 Movity, Inc
Licensed new-style BSD, also containing Jasmine, which is licensed MIT. See LICENSE file for more information.
